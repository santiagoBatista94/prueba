import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import axios from "axios";
import translate from "node-google-translate-skidz";

const app = express();
const PORT = 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "views")));

app.get("/", (req, res) => {
    res.render("index");
});

app.get("/search", async (req, res) => {
    const departmentId = req.query.departmentId || "";
    const keyword = req.query.keyword || "";
    
const hasImages = req.query.hasImages || "";
    const geoLocation = req.query.geoLocation || "";
    let url = `https://collectionapi.metmuseum.org/public/collection/v1/search?`;

    if (departmentId) url += `&departmentId=${departmentId}`;
    if (keyword) url += `&q=${keyword}`;
    if (hasImages) url += `&hasImages=true`;
    if (geoLocation) url += `&geoLocation=${geoLocation}`;

    try {
        const response = await axios.get(url);

        if (!response.data || !Array.isArray(response.data.objectIDs) || response.data.objectIDs.length === 0) {
            return res.json({ objects: [], message: "No hay resultados" });
        }

        let objectIDs = response.data.objectIDs
        const objects = await Promise.all(
            objectIDs.map(async (id) => {
                const objResponse = await axios.get(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`);
                const object = objResponse.data;
                // Traducir título, cultura y dinastía
                object.title = await translateText(object.title || 'Sin título');
                object.culture = await translateText(object.culture || 'Desconocida');
                object.dynasty = await translateText(object.dynasty || 'Desconocida');
                return object;
            })
        );








        res.json({ objects });
    } catch (error) {
        console.error("Error fetching data from the API:", error.message);
        res.status(500).json({ message: "Error interno del servidor" });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});